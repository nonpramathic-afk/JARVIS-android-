# JARVIS PHONE-ONLY

This project removes the laptop/server dependency.

Architecture:
Android phone -> OpenAI API -> response -> Android voice output.

The app includes:
- Futuristic JARVIS interface
- Text chat
- Android speech recognition
- Android text-to-speech
- OpenAI Responses API
- Web search tool
- Local API-key storage
- Settings screen

## Important security note

For a personal prototype, the app stores the API key locally on the device and sends it directly to the OpenAI API.
For a public Play Store release, do NOT embed a shared API key in an app. Use a secure backend with authentication and rate limits.

## Build

Open this project in Android Studio or a cloud Android development environment and build an APK.

Android's speech APIs require microphone permission and Android's TTS system provides spoken output. The manifest includes the required service queries.

## What this cannot do yet

Android intentionally limits arbitrary control of other apps and sensitive device functions. Those features require the appropriate Android permissions, intents, accessibility/special access, or system privileges. JARVIS should request only the permissions needed for the action.
