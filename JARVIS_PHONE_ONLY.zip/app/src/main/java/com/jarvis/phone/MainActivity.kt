package com.jarvis.phone

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private val client = OkHttpClient()
    private val voiceCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input=findViewById(R.id.input); chat=findViewById(R.id.chat); status=findViewById(R.id.status)
        prefs=getSharedPreferences("jarvis",MODE_PRIVATE); tts=TextToSpeech(this,this)

        findViewById<Button>(R.id.send).setOnClickListener { ask(input.text.toString()) }
        findViewById<ImageButton>(R.id.mic).setOnClickListener { listen() }
        findViewById<Button>(R.id.settings).setOnClickListener { settings() }

        if (prefs.getString("apiKey", "").isNullOrBlank()) settings()
        else { status.text="● SYSTEM READY"; add("JARVIS","Good evening. I am ready.") }
    }

    private fun ask(text:String) {
        if(text.isBlank()) return
        val key=prefs.getString("apiKey","") ?: ""
        if(key.isBlank()){ settings(); return }
        add("YOU",text); input.setText(""); status.text="● THINKING…"
        val body=JSONObject()
            .put("model",prefs.getString("model","gpt-5.6") ?: "gpt-5.6")
            .put("input",JSONArray().put(JSONObject().put("role","developer").put("content",
                "You are JARVIS, a calm, intelligent personal AI assistant. Be concise, natural and honest. " +
                "You are running directly on an Android phone. Never claim to have performed an Android action unless the app actually did it. " +
                "Ask confirmation before sensitive actions. The user wants a futuristic JARVIS experience." ))
                .put(JSONObject().put("role","user").put("content",text)))
            .put("tools",JSONArray().put(JSONObject().put("type","web_search")))
        val req=Request.Builder().url("https://api.openai.com/v1/responses")
            .post(RequestBody.create("application/json".toMediaTypeOrNull(),body.toString()))
            .addHeader("Authorization","Bearer $key").addHeader("Content-Type","application/json").build()
        client.newCall(req).enqueue(object:Callback{
            override fun onFailure(call:Call,e:IOException){runOnUiThread{status.text="● ERROR";add("JARVIS","I couldn't connect to the AI service.")}}
            override fun onResponse(call:Call,response:Response){
                val raw=response.body?.string()?:"{}"
                val answer=extract(raw)
                runOnUiThread{status.text="● SYSTEM ONLINE";add("JARVIS",answer);speak(answer)}
            }
        })
    }

    private fun extract(raw:String):String{
        try{
            val o=JSONObject(raw)
            val out=o.optJSONArray("output") ?: return raw
            for(i in 0 until out.length()){
                val item=out.getJSONObject(i)
                val content=item.optJSONArray("content") ?: continue
                for(j in 0 until content.length()){
                    val c=content.getJSONObject(j)
                    if(c.optString("type")=="output_text") return c.optString("text")
                }
            }
        }catch(_:Exception){}
        return "I received a response, but couldn't read it."
    }

    private fun add(who:String,text:String){
        chat.append("\n$who\n$text\n")
        findViewById<ScrollView>(R.id.scroll).post{findViewById<ScrollView>(R.id.scroll).fullScroll(ScrollView.FOCUS_DOWN)}
    }

    private fun listen(){
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),voiceCode);return
        }
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN")
        startActivityForResult(i,voiceCode)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==voiceCode && resultCode==RESULT_OK){
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{ask(it)}
        }
    }

    private fun speak(text:String){tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis")}
    override fun onInit(code:Int){tts.language=Locale("en","IN");tts.setSpeechRate(.95f)}

    private fun settings(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(25,5,25,5)
        val key=EditText(this);key.hint="OpenAI API key";key.inputType=129;key.setText(prefs.getString("apiKey",""))
        val model=EditText(this);model.hint="Model (default gpt-5.6)";model.setText(prefs.getString("model","gpt-5.6"))
        box.addView(key);box.addView(model)
        AlertDialog.Builder(this).setTitle("JARVIS CORE SETTINGS")
            .setMessage("Your API key is stored locally on this phone. Do not share it.")
            .setView(box).setPositiveButton("SAVE"){_,_->
                prefs.edit().putString("apiKey",key.text.toString().trim()).putString("model",model.text.toString().trim()).apply()
                status.text="● SYSTEM READY"
            }.setNegativeButton("CANCEL",null).show()
    }

    override fun onDestroy(){tts.shutdown();super.onDestroy()}
}
